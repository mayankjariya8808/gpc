import React, { useState, useEffect, useMemo } from 'react';
import { Box, Typography, TextField, Button, List, ListItem, ListItemText, IconButton } from '@mui/material';
import DeleteIcon from '@mui/icons-material/Delete';
import { useParams, useLocation, useNavigate } from 'react-router-dom'; // Import useNavigate
import axios from 'axios';

const Expense = () => {
    const { memberId } = useParams();
    const location = useLocation();
    const navigate = useNavigate(); // Initialize useNavigate
    const { updateMemberExpense } = location.state || { updateMemberExpense: null };
    const [expenses, setExpenses] = useState([]);
    const [description, setDescription] = useState('');
    const [amount, setAmount] = useState('');

    useEffect(() => {
        const fetchExpenses = async () => {
            try {
                const res = await axios.get(`http://localhost:5000/api/members/${memberId}/expenses`);
                setExpenses(res.data);
            } catch (error) {
                console.error('Error fetching expenses:', error);
            }
        };
        fetchExpenses();
    }, [memberId]);

    const handleAddExpense = async () => {
        if (description && !isNaN(amount) && amount > 0) {
            const newExpense = { description, amount: parseFloat(amount) };
            try {
                const res = await axios.post(`http://localhost:5000/api/members/${memberId}/expenses`, newExpense);
                setExpenses([...expenses, res.data]);
                setDescription('');
                setAmount('');
            } catch (error) {
                console.error('Error adding expense:', error.response?.data || error.message);
            }
        } else {
            alert('Please enter a valid description and amount greater than zero.');
        }
    };

    const handleDeleteExpense = async (id) => {
        try {
            await axios.delete(`http://localhost:5000/api/expenses/${id}`);
            const updatedExpenses = expenses.filter(expense => expense._id !== id);
            setExpenses(updatedExpenses);
        } catch (error) {
            console.error('Error deleting expense:', error.response?.data || error.message);
        }
    };

    const storeTotalExpenseInBackend = async (total) => {
        try {
            await axios.put(`http://localhost:5000/api/members/${memberId}/total-expense`, { totalExpense: total });
        } catch (error) {
            console.error('Error updating total expense:', error.response?.data || error.message);
        }
    };

    const totalExpense = useMemo(() => {
        const total = expenses.reduce((sum, expense) => sum + expense.amount, 0);
        if (updateMemberExpense) {
            updateMemberExpense(memberId, total);
        }
        storeTotalExpenseInBackend(total); // Call to store the total expense
        return total;
    }, [expenses, memberId, updateMemberExpense]);

    return (
        <Box sx={{ padding: 4 }}>
            

            {/* Back Button */}
            <Button 
                variant="outlined" 
                sx={{ marginBottom: 2 }} 
                onClick={() => navigate(-1)} // Navigate back to the previous page
            >
                Back
            </Button>

            <Typography variant="h4" gutterBottom sx={{ color: '#008080', fontSize: '2rem', fontWeight: 'bold' }}>
                Expenses for Member
            </Typography>
            <Typography variant="h4" gutterBottom sx={{ color: '#FF6347', fontWeight: 'bold', fontSize: '1.8rem' }}>
                Total Expense: ${totalExpense.toFixed(2)}
            </Typography>

            <Box sx={{ display: 'flex', gap: 2, marginBottom: 2 }}>
                <TextField
                    label="Description"
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                />
                <TextField
                    label="Amount"
                    type="number"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                />
                <Button variant="contained" onClick={handleAddExpense}>
                    Add Expense
                </Button>
            </Box>
            <List>
                {expenses.map((expense) => (
                    <ListItem
                        key={expense._id}
                        sx={{
                            backgroundColor: '#f0f8ff',
                            marginBottom: 2,
                            borderRadius: 2,
                            '&:hover': {
                                backgroundColor: '#e6e6fa',
                            },
                        }}
                        secondaryAction={
                            <IconButton edge="end" aria-label="delete" onClick={() => handleDeleteExpense(expense._id)}>
                                <DeleteIcon sx={{ color: '#ff4500', fontSize: 28 }} />
                            </IconButton>
                        }
                    >
                        <ListItemText
                            primary={
                                <Typography variant="h6" sx={{ color: '#4b0082', fontWeight: 'bold' }}>
                                    {expense.description}
                                </Typography>
                            }
                            secondary={
                                <Typography variant="h5" sx={{ color: '#008000' }}>
                                    ${expense.amount.toFixed(2)}
                                </Typography>
                            }
                        />
                    </ListItem>
                ))}
            </List>
        </Box>
    );
};

export default Expense;
